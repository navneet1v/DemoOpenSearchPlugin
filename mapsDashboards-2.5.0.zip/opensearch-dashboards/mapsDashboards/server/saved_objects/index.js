"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "mapSavedObjectsType", {
  enumerable: true,
  get: function () {
    return _map_saved_object.mapSavedObjectsType;
  }
});

var _map_saved_object = require("./map_saved_object");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUtBIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIENvcHlyaWdodCBPcGVuU2VhcmNoIENvbnRyaWJ1dG9yc1xuICogU1BEWC1MaWNlbnNlLUlkZW50aWZpZXI6IEFwYWNoZS0yLjBcbiAqL1xuXG5leHBvcnQgeyBtYXBTYXZlZE9iamVjdHNUeXBlIH0gZnJvbSAnLi9tYXBfc2F2ZWRfb2JqZWN0JztcbiJdfQ==